import read_file
import re
import sys
#import numpy as np
#import matplotlib.pyplot as plt

    
def create_plot(infile, outfile):
    dicts = {}
    write_file = open(outfile + "summary.txt", 'w')
    for i in open(infile):
        if not i.startswith('#'):
            if 'Gene.refGene' not in i:
                split_i = i.split('\t')
                if split_i[8] not in dicts:
                    dicts[split_i[8]] = [1]
                else:
                    dicts[split_i[8]].append(1)
    
    for k, v in dicts.iteritems():
        write_file.write(k + '\t' + str(len(v)) + '\n')
    write_file.close()


     

def create_DB(variant_file, NP_and_NM, refGeneVersion, refseq, db_file, ):
    dicts_nm_np = {}
    dicts_refseq = {}
    dicts_nm_list = {}
    seq_nonRed = {}
    write_file = open(db_file, 'w')
    #variant_file = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/MFM223/MFM223_filtered_1.txt"
    #NP_and_NM = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Protein_file_NM_NP/NP_and_NM.txt" #folder_2
    #refGeneVersion = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Protein_file_NM_NP/hg19_refGeneVersion.txt" #
    #refseq = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/RefSeq/homo_sapiens_RS81.fasta"
    #Load the NM_MP_file0
    for i in open(NP_and_NM):
            split_line = i.split('\t')
            dicts_nm_np[split_line[0]] = split_line[1].rstrip()

    #Load the NM_list with version number
    for nm_line in open(refGeneVersion):
            split_nm_line = nm_line.split('\t')
            dicts_nm_list[split_nm_line[0]] = split_nm_line[1].rstrip()
                    
    # Load the refseq file
    read_refseq = read_file.read_fasta(refseq)
    for rows in read_refseq:
            dicts_refseq[rows[0].split('|')[3]] = rows[0] + '@' + rows[1].rstrip()

    #Maping the variants
    cnt = 10000 # for Exome_seq
    #cnt = 00001 # for RNASeq
    for variant in open(variant_file):
        if not variant.startswith('#'): 
            var_line = variant.split('\t')
            if var_line[5] == "exonic" and var_line[8] =="nonsynonymous SNV":
                for ind_var in var_line[9].split(','):
                        if ind_var.split(':')[1] in dicts_nm_list:
                                if ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]] in dicts_nm_np:
                                        #print dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()
                                        if dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip() in dicts_refseq:
                                                #print ind_var.split(':')[4],  re.findall('\d+', ind_var.split(':')[4]), ind_var.split(':')[4][2], ind_var.split(':')[4][-1]
                                                mutation_location = re.findall('\d+', ind_var.split(':')[4])
                                                conv_mut_loc = int(mutation_location[0])
                                                mut_start = ind_var.split(':')[4][2]
                                                mut_end = ind_var.split(':')[4][-1]
                                                sequence = dicts_refseq[dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()].split('@')[1]
                                                
                                                header = dicts_refseq[dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].split('@')[0].rstrip()].split('|')[4].split('#')[1:4]
                                                if sequence[conv_mut_loc -1] == mut_start:
                                                        cnt+=1
                                                        seq = header[2].split('@')[1].rstrip()[:int(mutation_location[0])-1] + mut_end + header[2].split('@')[1].rstrip()[int(mutation_location[0]):]
                                                        if seq.rstrip()  not in seq_nonRed:
                                                            seq_nonRed[seq.rstrip()] = 1
                                                            write_file.write('>gi|' + str(cnt) + '|ref|' + dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()  + '| ' + dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip() + '_' + ind_var.split(':')[4].split('.')[1] +'#'+ header[0] + '#' + header[1] + '#' + header[2].split('@')[0].rstrip() + '\n' + seq.rstrip() + '\n')

    write_file.close()



##if __name__=="__main__":
##        a = create_DB(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
if __name__=="__main__":
    if len(sys.argv) > 5:
            a = create_DB(sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
            create_plot(sys.argv[1], sys.argv[6])
    else:
        #print sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5]
        print "Usage Create_DB.exe gatk_variant_file.vcf, np_nm.txt, hg19_refGeneversion.txt RefSeq_fasta output_fasta_file.fasta"
