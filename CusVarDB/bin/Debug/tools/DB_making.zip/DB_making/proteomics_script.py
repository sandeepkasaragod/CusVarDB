import read_file
from itertools import islice
import re
'''
#Step1: filtering the annovar vcf files based on exonic and non synonymous and stop loss
folder_1 = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/MFM223/MFM223_annotated.hg19_multianno.txt" 
write_file = open("/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/MFM223/MFM223_filtered_1.txt", 'w')
for i in open(folder_1):
	split_line = i.split('\t')
	if split_line[5] == "exonic" and split_line[8] =="nonsynonymous SNV":# or split_line[8] == "stoploss":
		write_file.write(i.rstrip() + '\n')

write_file.close()
#Step1 ends
'''

#Step2: Map the variants to protein database"
#Output file name  celline_name_custome_mutantDB.fasta
dicts_nm_np = {}
dicts_refseq = {}
dicts_nm_list = {}
variant_file = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/MFM223/MFM223_filtered_1.txt"
folder_2 = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Protein_file_NM_NP/NP_and_NM.txt"
folder_nm = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Protein_file_NM_NP/hg19_refGeneVersion.txt"
folder_refseq = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/RefSeq/homo_sapiens_RS81.fasta"
#Load the NM_MP_file0
for i in open(folder_2):
	split_line = i.split('\t')
	dicts_nm_np[split_line[0]] = split_line[1].rstrip()

#Load the NM_list with version number
for nm_line in open(folder_nm):
	split_nm_line = nm_line.split('\t')
	dicts_nm_list[split_nm_line[0]] = split_nm_line[1].rstrip()
		
# Load the refseq file
read_refseq = read_file.read_fasta(folder_refseq)
for rows in read_refseq:
	dicts_refseq[rows[0].split('|')[3]] = rows[0] + '@' + rows[1].rstrip()

#Maping the variants
cnt = 10000 # for Exome_seq
#cnt = 00001 # for RNASeq
for variant in open(variant_file):
	var_line = variant.split('\t')
	for ind_var in var_line[9].split(','):
		if ind_var.split(':')[1] in dicts_nm_list:
			if ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]] in dicts_nm_np:
				#print dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()
				if dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip() in dicts_refseq:
					#print ind_var.split(':')[4],  re.findall('\d+', ind_var.split(':')[4]), ind_var.split(':')[4][2], ind_var.split(':')[4][-1]
					mutation_location = re.findall('\d+', ind_var.split(':')[4])
					conv_mut_loc = int(mutation_location[0])
					mut_start = ind_var.split(':')[4][2]
					mut_end = ind_var.split(':')[4][-1]
					sequence = dicts_refseq[dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()].split('@')[1]
					
					header = dicts_refseq[dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].split('@')[0].rstrip()].split('|')[4].split('#')[1:4]
					if sequence[conv_mut_loc -1] == mut_start:
						cnt+=1
						seq = header[2].split('@')[1].rstrip()[:int(mutation_location[0])-1] + mut_end + header[2].split('@')[1].rstrip()[int(mutation_location[0]):]

						print '>gi|' + str(cnt) + '|ref|' + dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip()  + '| ' + dicts_nm_np[ind_var.split(':')[1] + '.' + dicts_nm_list[ind_var.split(':')[1]]].rstrip() + '_' + ind_var.split(':')[4].split('.')[1] +'#'+ header[0] + '#' + header[1] + '#' + header[2].split('@')[0].rstrip() + '\n' + seq.rstrip()
#Step2 Ends

'''
#Comparing the RNASeq and Exome custome protein DB
# USe the current script when both the Exome and RNASeq annovar files are available

Exome_file_path = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Custome_mutation_database/MDAMB231_Exome/MDAMB231_Exome_mutant_db.fasta"
RNASeq_file_path = "/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Custome_mutation_database/MDAMB231_RNASeq/MDAMB231_RNASeq_custome_mutantDB.fasta"
Exome_dict = {}

read_Exome_file = read_file.read_fasta(Exome_file_path)
for read_line in read_Exome_file:
	Exome_dict[read_line[1].rstrip()] = read_line[1].rstrip()

read_RNASeq_file = read_file.read_fasta(RNASeq_file_path)
for read_line_RNA in read_RNASeq_file:
	if read_line_RNA[1].rstrip() not in Exome_dict:
		print '>' + read_line_RNA[0].rstrip() + '\n' + read_line_RNA[1].rstrip()
'''
'''		
#Step 3 begins
# After PD search XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#Checking the proteomics peptides with single line Refseq to remove the know peptides (Mutant peptide filteration)
seq_single_line = ''
refseq_single_line = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/RefSeq/HsRefSeq81_crap_singleline.fasta'
peptide_group = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/MDAMB436/MDAMB436_LysC_Tryp_011619_PeptideGroups.txt'
mut_ref_pep_loc = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/MDAMB436/'
mutant_pep = open(mut_ref_pep_loc + 'mutant_pep.txt', 'w')
refseq_pep = open(mut_ref_pep_loc + 'RefSeq_pep.txt', 'w')
for line in open(refseq_single_line):
	seq_single_line = line.rstrip()

for pep_line in open(peptide_group):
	split_line = pep_line.split('\t')
	#if split_line[3].strip() not in seq_single_line:
	if split_line[3].replace('"', '') not in seq_single_line:
		mutant_pep.write(pep_line.rstrip() + '\n')
	else:
		refseq_pep.write(pep_line.rstrip() + '\n')
mutant_pep.close()
refseq_pep.close()
# Step 3 ends
'''
'''
#Step 4 begins
# provide the file name while running on terminal #Mutant_pep_with_gene_id_name_protein_description.txt
# retreiving the mutation location and protein accession #Mutation_loc, #Protein_acc, #gene_symbol and $gene_id
mutant_db = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Custome_mutation_database/MDAMB231_Exome/MDAMB231_Exome_mutant_db.fasta'
mutant_variant_file = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/MDAMB231/mutant_pep.txt'
dicts_refseq = {}
#Load the custome mutant proteome db
rds = read_file.read_fasta(mutant_db)
for rows in rds:
	split_row = rows[0].split('|')
	get_values = split_row[4].split('#')
	#print get_values[0], get_values[1], get_values[2], get_values[3]
	dicts_refseq[split_row[1]] = rows[0]

with open(mutant_variant_file) as fl:
	for mt_var_line in islice(fl, 1, None):
		master_acc =  mt_var_line.split('\t')[15].replace('"', '') #Master protein accession
		if master_acc.split(';')[0] in dicts_refseq:
			split_annot = dicts_refseq[master_acc.split(';')[0]].split('|')
			get_gn_id_name = split_annot[4].split('#')
			print get_gn_id_name[0].split('_')[0] + '_' + get_gn_id_name[0].split('_')[1] + '\t' + get_gn_id_name[0].split('_')[2]+ '\t' + get_gn_id_name[1]+ '\t' + get_gn_id_name[2] + '\t' + get_gn_id_name[3] + '\t' + mt_var_line.rstrip()	
#Step 4 ends
'''
'''
#Step 5 begins
#Variant retreival based on Allele frequency and Predictions(SIFT, PolyPhen......)
def get_dup_index(instring, seperator):
    get_np = [i for i in range(len(instring)) if instring.startswith(seperator, i)]
    return get_np

variant_file_protein_gp = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/MDAMB231/MDAMB231_peptides_with_gene_id_and_description.txt'
variant_file_vcf = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/MDAMB231/MDAMB231_filtered_1.txt'
variant_vcf_dicts = {}
variant_protein_dicts = {}
#Read file from 2nd line (headers are skipped)
with open(variant_file_protein_gp)as f:
	for variant_v_prot in islice(f, 1, None):
		split_v_prot = variant_v_prot.split('\t')
		variant_protein_dicts[split_v_prot[2] + "_" + split_v_prot[1]] = variant_v_prot.rstrip()
		
for var_vcf_line in open(variant_file_vcf):
	split_var_vcf = var_vcf_line.split('\t')
	if ',' not in split_var_vcf[9]:
		splt_res = split_var_vcf[9].split(':')
		var_vcf_var = splt_res[0] + "_" + splt_res[-1].split('.')[1]
		
		if var_vcf_var in variant_protein_dicts:
			get_string = split_var_vcf[-1].rstrip()
			get_colon = get_dup_index(get_string, ':')
			if len(get_colon) == 4:
				get_read1 = get_string[get_colon[0] : get_colon[1]]
		        	get_comma = get_dup_index(get_read1, ',')
		        	AD_draft = get_read1[get_comma[0] + 1:]
		        	if not "," in AD_draft:
		            		AD = AD_draft
		            		DP = str(get_string)[get_colon[1] + 1: get_colon[2]]
		            		allele_freq = (float(AD) / float(DP))
		            		if allele_freq >= 0.20 and allele_freq <= 0.70:
		                		if int(AD)>=10:
							#if split_var_vcf[13] !='.' and split_var_vcf[18] != '.': #1000g, ExAC_ALL
								#if float(split_var_vcf[13]) <= 0.15 and float(split_var_vcf[18]) <= 0.15:
									#if split_var_vcf[33] == 'D' or split_var_vcf[35] == 'D' or split_var_vcf[35] == 'P' or split_var_vcf[41] == 'A' or split_var_vcf[41] == 'D' or split_var_vcf[43] == 'H': # SIFT, PolyPhen, Mutation_taster, Mutation_accessor
							print split_var_vcf[-2].rstrip() + '\t' + split_var_vcf[-1].rstrip() + '\t' + str(AD) + '\t' + str(DP) + '\t' + str(allele_freq) + '\t' + variant_protein_dicts[var_vcf_var].rstrip() +'\t' + var_vcf_line.rstrip()
							
			elif len(get_colon) == 5:
				get_read1 = str(get_string)[get_colon[1]: get_colon[2]]
        			get_comma = get_dup_index(str(get_read1), ',')
        			AD_draft1 = get_read1[get_comma[0] + 1:]
        			if not "," in AD_draft1:
            				AD1 = AD_draft1
            				DP1 = str(get_string)[get_colon[2] + 1: get_colon[3]]
            				allele_freq1 = float(AD1) / float(DP1)
            				if allele_freq1 >= 0.20 and allele_freq1 <= 0.70:
                    				if int(AD1)>=10:
                                                        #if split_var_vcf[13] !='.' and split_var_vcf[18] != '.': #1000g, ExAC_ALL
                                                                #if float(split_var_vcf[13]) <= 0.15 and float(split_var_vcf[18]) <= 0.15:
                                                                        #if split_var_vcf[33] == 'D' or split_var_vcf[35] == 'D' or split_var_vcf[35] == 'P' or split_var_vcf[41] == 'A' or split_var_vcf[41] == 'D' or split_var_vcf[43] == 'H':
        						print split_var_vcf[-2].rstrip() + '\t' + split_var_vcf[-1].rstrip()+ '\t' + str(AD1) + '\t' + str(DP1) + '\t' + str(allele_freq1) + '\t' + variant_protein_dicts[var_vcf_var].rstrip() + '\t' + var_vcf_line.rstrip()
				
					
	else:
		for split_comma in split_var_vcf[9].split(','):
			split_res = split_comma.split(':')
                	var_vcf_var = split_res[0] + "_" + split_res[-1].split('.')[1]
                	if var_vcf_var in variant_protein_dicts:
                        	get_string = split_var_vcf[78] #AD:DP: vlaues == 0/1:540,45 .....
                        	get_colon = get_dup_index(get_string, ':')
                        	if len(get_colon) == 4:
                                	get_read1 = get_string[get_colon[0] : get_colon[1]]
                                	get_comma = get_dup_index(get_read1, ',')
                                	AD_draft = get_read1[get_comma[0] + 1:]
                                	if not "," in AD_draft:
                                        	AD = AD_draft
                                        	DP = str(get_string)[get_colon[1] + 1: get_colon[2]]
                                        	allele_freq = (float(AD) / float(DP))
                                        	if allele_freq >= 0.20 and allele_freq <= 0.70:
                                                        if int(AD)>=10:
                                                        	#if split_var_vcf[13] !='.' and split_var_vcf[18] != '.': #1000g, ExAC_ALL
                                                                	#if float(split_var_vcf[13]) <= 0.15 and float(split_var_vcf[18]) <= 0.15:
                                                                        	#if split_var_vcf[33] == 'D' or split_var_vcf[35] == 'D' or split_var_vcf[35] == 'P' or split_var_vcf[41] == 'A' or split_var_vcf[41] == 'D' or split_var_vcf[43] == 'H':
        							print split_var_vcf[-2].rstrip() + '\t' + split_var_vcf[-1].rstrip() + '\t' + str(AD) + '\t' + str(DP) + '\t' + str(allele_freq) + '\t' + variant_protein_dicts[var_vcf_var].rstrip() + '\t' + var_vcf_line.rstrip()
											
				elif len(get_colon) == 5:
                                	get_read1 = str(get_string)[get_colon[1]: get_colon[2]]
                                	get_comma = get_dup_index(str(get_read1), ',')
                                	AD_draft1 = get_read1[get_comma[0]+ 1 :]
                                	if not "," in AD_draft1:
                                        	AD1 = AD_draft1
                                        	DP1 = str(get_string)[get_colon[2] + 1: get_colon[3]]
                                        	allele_freq1 = float(AD1) / float(DP1)
                                        	if allele_freq1 >= 0.20 and allele_freq1 <= 0.70:
							if int(AD1)>=10:
                                                        	#if split_var_vcf[13] !='.' and split_var_vcf[18] != '.': #1000g, ExAC_ALL
                                                                	#if float(split_var_vcf[13]) <= 0.15 and float(split_var_vcf[18]) <= 0.15:
                                                                        	#if split_var_vcf[33] == 'D' or split_var_vcf[35] == 'D' or split_var_vcf[35] == 'P' or split_var_vcf[41] == 'A' or split_var_vcf[41] == 'D' or split_var_vcf[43] == 'H':
        							print split_var_vcf[-2].rstrip() + '\t' + split_var_vcf[-1].rstrip() + '\t' + str(AD1) + '\t' + str(DP1) + '\t' + str(allele_freq1) + '\t' +variant_protein_dicts[var_vcf_var].rstrip() +'\t' + var_vcf_line.rstrip()
			#print split_res[0] + "_" + split_res[-1].split('.')[1]

'''
'''
prot_DB = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Custome_mutation_database/BT474_Exome/BT474_variant_protDB_allele_filtered_HsRefSeq81_crap_071018.fasta'
variant_peptides = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/BT474_allel_freq_filtered_SEQUEST_MASCOT/mutant_pep.txt'
dicts_prot = {}
#reading the protein file
read_prot = read_file.read_fasta(prot_DB)
for read_line in read_prot:
	dicts_prot[read_line[0].split('|')[1]] = read_line[0] + '@' + read_line[1] # accession, header and sequence 

for read_var_pep in open(variant_peptides):
	split_pep_line = read_var_pep.split('\t') # Master protein accession 
	if split_pep_line[15].split(';')[0].replace('"', '').strip() in dicts_prot: # master_protein
		split_info = dicts_prot[split_pep_line[15].split(';')[0].replace('"', '').strip()].split('@') # master_protein
		header = split_info[0]
		split_header = header.split('|')
		print split_header[4].split('_')[0].lstrip() +  '_' +  split_header[4].split('_')[1] + '\t' + split_header[4].split('_')[2].split('#')[0] + '\t' +  split_header[4].split('#')[1] + '\t' + split_header[4].split('#')[2] + '\t' + split_header[4].split('#')[3] + '\t' + read_var_pep.rstrip()
'''

'''
#Fetch the VCF file details for variant peptide
variant_peptide_file = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Analysis/BT474_allel_freq_filtered_SEQUEST_MASCOT/BT474_mutant_peptides_with_gene_id_symbol_description.txt'
vcf_file = '/home/csbmm/Working_directory/Sandeep_K/Proteomics_scripts/Data_folder/BT474_Exome/BT474_Exome_filtered_1.txt'
nm_to_np_file = ''

dicts = {}
for j in open(vcf_file):
	split_j = j.split('\t')
	gene_mutation_loc = split_j[9] # Get the gene and mutation location column
	for gene_line in gene_mutation_loc.split(','):
		split_infos  = gene_mutation_loc.split(':')
		get_gene = split_infos[0]
		get_loc = split_infos[-1].split('.')[-1]
		dicts[get_gene.rstrip() + '_' + get_loc.rstrip()] = j.rstrip()

for var_pep in open(variant_peptide_file):
	split_var_pep = var_pep.split('\t')
	if split_var_pep[2]+ '_' + split_var_pep[1] in dicts:
		print var_pep.rstrip() + '\t' + dicts[split_var_pep[2] + '_' + split_var_pep[1]]
'''
